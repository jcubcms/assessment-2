( function( api ) {

	
	api.sectionConstructor['u3a-townsville'] = api.Section.extend( {

		
		attachEvents: function () {},

		
		isContextuallyActive: function () {
			return true;
		}
	} );

} )(customize );